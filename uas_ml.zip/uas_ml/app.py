import streamlit as st
import joblib
import numpy as np

# Load model
model = joblib.load("model/lung_cancer_model.pkl")

st.title("🫁 Prediksi Risiko Kanker Paru-paru")

st.write("Isi informasi berikut untuk memprediksi kemungkinan terkena kanker paru-paru.")

gender = st.selectbox("Jenis Kelamin", ["Pria", "Wanita"])
age = st.number_input("Umur", min_value=1, value=40)
smoking = st.selectbox("Merokok?", ["Tidak", "Ya"])
yellow_fingers = st.selectbox("Jari menguning?", ["Tidak", "Ya"])
anxiety = st.selectbox("Kecemasan?", ["Tidak", "Ya"])
peer_pressure = st.selectbox("Tekanan dari lingkungan?", ["Tidak", "Ya"])
chronic_disease = st.selectbox("Penyakit Kronis?", ["Tidak", "Ya"])
fatigue = st.selectbox("Sering lelah?", ["Tidak", "Ya"])
allergy = st.selectbox("Alergi?", ["Tidak", "Ya"])
wheezing = st.selectbox("Mengi (wheezing)?", ["Tidak", "Ya"])
alcohol = st.selectbox("Mengonsumsi alkohol?", ["Tidak", "Ya"])
coughing = st.selectbox("Sering batuk?", ["Tidak", "Ya"])
shortness = st.selectbox("Sesak napas?", ["Tidak", "Ya"])
swallowing = st.selectbox("Sulit menelan?", ["Tidak", "Ya"])
chest_pain = st.selectbox("Nyeri dada?", ["Tidak", "Ya"])

# Encode input
X_input = np.array([[
    1 if gender == "Pria" else 0,
    age,
    1 if smoking == "Ya" else 2,
    1 if yellow_fingers == "Ya" else 2,
    1 if anxiety == "Ya" else 2,
    1 if peer_pressure == "Ya" else 2,
    1 if chronic_disease == "Ya" else 2,
    1 if fatigue == "Ya" else 2,
    1 if allergy == "Ya" else 2,
    1 if wheezing == "Ya" else 2,
    1 if alcohol == "Ya" else 2,
    1 if coughing == "Ya" else 2,
    1 if shortness == "Ya" else 2,
    1 if swallowing == "Ya" else 2,
    1 if chest_pain == "Ya" else 2
]])

if st.button("Prediksi"):
    result = model.predict(X_input)[0]
    st.success("Hasil Prediksi: Risiko **TINGGI** terkena kanker paru-paru" if result == 1 else "Hasil Prediksi: Risiko **RENDAH** terkena kanker paru-paru")
